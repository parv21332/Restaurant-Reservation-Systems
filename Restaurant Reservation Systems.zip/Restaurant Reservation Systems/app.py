from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from functools import wraps
import qrcode
import io
import os

from config import Config
from database.mongodb import init_db
from models.user import User
from models.table import Table
from models.reservation import Reservation

app = Flask(__name__)
app.config.from_object(Config)

# Admin UPI ID
ADMIN_UPI_ID = "dobariyaparv21@oksbi"
ADMIN_UPI_NAME = "SmartDine Restaurant"
app.config.from_object(Config)

# Flask-Login setup
login_manager = LoginManager(app)
login_manager.login_view = "login"
login_manager.login_message_category = "info"


@login_manager.user_loader
def load_user(user_id):
    return User.get_by_id(user_id)


# ── Context processor — inject pending count into every template ──────────────
@app.context_processor
def inject_pending_count():
    try:
        count = Reservation.count_pending_verification()
    except Exception:
        count = 0
    return {"pending_payment_count": count}


# ── Admin-only decorator ──────────────────────────────────────────────────────
def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash("Admin access required.", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated


# ── Public routes ─────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")

        if not all([name, email, phone, password]):
            flash("All fields are required.", "danger")
        elif password != confirm:
            flash("Passwords do not match.", "danger")
        elif len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
        else:
            user = User.create(name, email, phone, password)
            if user is None:
                flash("Email already registered.", "danger")
            else:
                flash("Account created! Please log in.", "success")
                return redirect(url_for("login"))

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        user = User.verify_password(email, password)
        if user:
            login_user(user)
            next_page = request.args.get("next")
            return redirect(next_page or url_for("dashboard"))
        flash("Invalid email or password.", "danger")

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out successfully.", "info")
    return redirect(url_for("index"))


# ── Customer routes ───────────────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    reservations = Reservation.get_by_user(current_user.id)
    # Enrich with table data
    enriched = []
    for r in reservations:
        table = Table.get_by_id(r.table_id)
        enriched.append({"reservation": r, "table": table})
    return render_template("dashboard.html", items=enriched)


@app.route("/reservation", methods=["GET", "POST"])
@login_required
def reservation():
    # Admins are not allowed to book tables
    if current_user.is_admin():
        flash("Admins cannot make reservations.", "danger")
        return redirect(url_for("admin"))

    if request.method == "POST":
        date = request.form.get("reservation_date", "").strip()
        time = request.form.get("reservation_time", "").strip()
        guests = request.form.get("guests", "0").strip()

        if not all([date, time, guests]):
            flash("All fields are required.", "danger")
            return redirect(url_for("reservation"))

        try:
            guests = int(guests)
            if guests < 1:
                raise ValueError
        except ValueError:
            flash("Please enter a valid number of guests.", "danger")
            return redirect(url_for("reservation"))

        available = Table.get_available(guests)
        if not available:
            flash("No tables available for the selected criteria.", "warning")
            return redirect(url_for("reservation"))

        # Pick the smallest suitable table (best fit)
        table = available[0]
        result = Reservation.create(current_user.id, table.id, date, time, guests)
        if result is None:
            flash("That time slot is fully booked. Please choose another time.", "warning")
        else:
            # Redirect to payment page
            return redirect(url_for("payment", reservation_id=result.id))

    return render_template("reservation.html")


@app.route("/reservation/cancel/<reservation_id>", methods=["POST"])
@login_required
def cancel_reservation(reservation_id):
    Reservation.cancel(reservation_id, user_id=current_user.id)
    flash("Reservation cancelled.", "info")
    return redirect(url_for("dashboard"))


# ── Payment routes ────────────────────────────────────────────────────────────
@app.route("/payment/<reservation_id>")
@login_required
def payment(reservation_id):
    if current_user.is_admin():
        return redirect(url_for("admin"))
    r = Reservation.get_by_id(reservation_id)
    if not r or r.user_id != current_user.id:
        flash("Reservation not found.", "danger")
        return redirect(url_for("dashboard"))
    table = Table.get_by_id(r.table_id)
    upi_link = (
        f"upi://pay?pa={ADMIN_UPI_ID}"
        f"&pn={ADMIN_UPI_NAME.replace(' ', '%20')}"
        f"&am={r.amount}"
        f"&cu=INR"
        f"&tn=Reservation%20{reservation_id[:8]}"
    )
    return render_template(
        "payment.html",
        reservation=r,
        table=table,
        upi_link=upi_link,
        upi_id=ADMIN_UPI_ID,
        upi_name=ADMIN_UPI_NAME,
    )


@app.route("/payment/<reservation_id>/qr")
@login_required
def payment_qr(reservation_id):
    """Generate and serve the UPI QR code image."""
    r = Reservation.get_by_id(reservation_id)
    if not r:
        return "Not found", 404

    upi_link = (
        f"upi://pay?pa={ADMIN_UPI_ID}"
        f"&pn={ADMIN_UPI_NAME.replace(' ', '%20')}"
        f"&am={r.amount}"
        f"&cu=INR"
        f"&tn=Reservation%20{reservation_id[:8]}"
    )
    img = qrcode.make(upi_link)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return send_file(buf, mimetype="image/png")


@app.route("/payment/<reservation_id>/confirm", methods=["POST"])
@login_required
def confirm_payment(reservation_id):
    if current_user.is_admin():
        return redirect(url_for("admin"))
    r = Reservation.get_by_id(reservation_id)
    if not r or r.user_id != current_user.id:
        flash("Reservation not found.", "danger")
        return redirect(url_for("dashboard"))

    upi_txn_id = request.form.get("upi_txn_id", "").strip()
    if not upi_txn_id:
        flash("Please enter your UPI Transaction ID.", "danger")
        return redirect(url_for("payment", reservation_id=reservation_id))

    Reservation.update_payment(reservation_id, upi_txn_id)
    flash("Payment submitted! Your reservation is now pending admin approval.", "success")
    return redirect(url_for("dashboard"))


# ── Admin routes ──────────────────────────────────────────────────────────────
@app.route("/admin")
@login_required
@admin_required
def admin():
    reservations = Reservation.get_all()
    enriched = []
    for r in reservations:
        table = Table.get_by_id(r.table_id)
        user = User.get_by_id(r.user_id)
        enriched.append({"reservation": r, "table": table, "user": user})

    tables = Table.get_all()
    customers = User.get_all_customers()
    summary = Reservation.get_financial_summary()
    total_revenue = summary["net"]   # net revenue (paid - refunded)

    # Pending refunds
    pending_refunds = Reservation.get_pending_refunds()
    refund_items = []
    for r in pending_refunds:
        user = User.get_by_id(r.user_id)
        refund_items.append({"reservation": r, "user": user})

    return render_template(
        "admin.html",
        items=enriched,
        tables=tables,
        customers=customers,
        total_revenue=total_revenue,
        refund_items=refund_items,
        summary=summary,
    )


@app.route("/admin/reservation/<reservation_id>/status", methods=["POST"])
@login_required
@admin_required
def update_reservation_status(reservation_id):
    status = request.form.get("status")
    if status in ("confirmed", "rejected", "cancelled"):
        Reservation.update_status(reservation_id, status)
        if status == "rejected":
            r = Reservation.get_by_id(reservation_id)
            if r and r.refund_status == "pending":
                flash("Reservation rejected. Refund is marked as pending — please send money back to the customer.", "warning")
            else:
                flash("Reservation rejected.", "warning")
        else:
            flash(f"Reservation marked as {status}.", "success")
    return redirect(url_for("admin"))


@app.route("/admin/refund/<reservation_id>", methods=["POST"])
@login_required
@admin_required
def process_refund(reservation_id):
    refund_upi_id = request.form.get("refund_upi_id", "").strip()
    if not refund_upi_id:
        flash("Please enter the customer's UPI ID to process the refund.", "danger")
        return redirect(url_for("admin_refunds"))
    Reservation.mark_refund_sent(reservation_id, refund_upi_id)
    flash(f"Refund marked as sent to {refund_upi_id}. Revenue updated.", "success")
    # Determine where to redirect back
    next_page = request.form.get("next", "admin_refunds")
    return redirect(url_for(next_page))


@app.route("/admin/refunds")
@login_required
@admin_required
def admin_refunds():
    summary = Reservation.get_financial_summary()

    # All refund records (pending + sent)
    all_refunds = Reservation.get_all_refunds()
    refund_items = []
    for r in all_refunds:
        user = User.get_by_id(r.user_id)
        table = Table.get_by_id(r.table_id)
        refund_items.append({"reservation": r, "user": user, "table": table})

    # Split into pending vs completed
    pending = [i for i in refund_items if i["reservation"].refund_status == "pending"]
    completed = [i for i in refund_items if i["reservation"].refund_status == "sent"]

    return render_template(
        "refunds.html",
        summary=summary,
        pending=pending,
        completed=completed,
    )


@app.route("/admin/payments")
@login_required
@admin_required
def admin_payments():
    """Payment verification dashboard."""
    pending = Reservation.get_pending_verification()
    pending_items = []
    for r in pending:
        user  = User.get_by_id(r.user_id)
        table = Table.get_by_id(r.table_id)
        pending_items.append({"reservation": r, "user": user, "table": table})

    # All verified / failed history
    from database.mongodb import reservations_collection
    history_docs = reservations_collection.find(
        {"payment_verified": {"$in": ["verified", "failed"]}}
    ).sort("verified_at", -1)
    history = []
    for doc in history_docs:
        r     = Reservation(doc)
        user  = User.get_by_id(str(doc["user_id"]))
        table = Table.get_by_id(str(doc["table_id"]))
        history.append({"reservation": r, "user": user, "table": table})

    pending_count = len(pending_items)
    return render_template(
        "verify_payments.html",
        pending_items=pending_items,
        history=history,
        pending_count=pending_count,
    )


@app.route("/admin/payments/<reservation_id>/verify", methods=["POST"])
@login_required
@admin_required
def verify_payment(reservation_id):
    note = request.form.get("note", "").strip()
    Reservation.verify_payment(reservation_id, note)
    flash("Payment verified. Reservation confirmed.", "success")
    return redirect(url_for("admin_payments"))


@app.route("/admin/payments/<reservation_id>/fail", methods=["POST"])
@login_required
@admin_required
def fail_payment(reservation_id):
    note = request.form.get("note", "").strip()
    Reservation.fail_payment(reservation_id, note)
    flash("Payment marked as failed. Customer must re-submit payment.", "warning")
    return redirect(url_for("admin_payments"))


@app.route("/admin/table/add", methods=["POST"])
@login_required
@admin_required
def add_table():
    table_number = request.form.get("table_number")
    capacity = request.form.get("capacity")
    try:
        Table.add_table(int(table_number), int(capacity))
        flash("Table added successfully.", "success")
    except Exception:
        flash("Invalid table data.", "danger")
    return redirect(url_for("admin"))


@app.route("/admin/table/delete/<table_id>", methods=["POST"])
@login_required
@admin_required
def delete_table(table_id):
    Table.delete_table(table_id)
    flash("Table deleted.", "info")
    return redirect(url_for("admin"))


@app.route("/admin/reservation/delete/<reservation_id>", methods=["POST"])
@login_required
@admin_required
def delete_reservation(reservation_id):
    Reservation.delete(reservation_id)
    flash("Reservation deleted.", "info")
    return redirect(url_for("admin"))


# ── API: available tables (AJAX) ──────────────────────────────────────────────
@app.route("/api/tables/available")
@login_required
def api_available_tables():
    guests = request.args.get("guests", 1, type=int)
    tables = Table.get_available(guests)
    return jsonify([{"id": t.id, "table_number": t.table_number, "capacity": t.capacity} for t in tables])


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    app.run(debug=Config.DEBUG)
