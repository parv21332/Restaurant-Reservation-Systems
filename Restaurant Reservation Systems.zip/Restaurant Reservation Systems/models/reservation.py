from bson import ObjectId
from datetime import datetime
from database.mongodb import reservations_collection, tables_collection

# Pricing: Rs. 200 per guest as booking advance
PRICE_PER_GUEST = 200


class Reservation:
    def __init__(self, doc):
        self.id = str(doc["_id"])
        self.user_id = str(doc["user_id"])
        self.table_id = str(doc["table_id"])
        self.reservation_date = doc["reservation_date"]
        self.reservation_time = doc["reservation_time"]
        self.guests = doc["guests"]
        self.status = doc.get("status", "pending")
        self.amount = doc.get("amount", 0)
        self.payment_status = doc.get("payment_status", "unpaid")
        self.upi_txn_id = doc.get("upi_txn_id", "")
        # payment_verified: unverified | verified | failed
        self.payment_verified = doc.get("payment_verified", "unverified")
        self.verified_at = doc.get("verified_at")
        self.verify_note = doc.get("verify_note", "")
        # refund_status: none | pending | sent
        self.refund_status = doc.get("refund_status", "none")
        self.refund_upi_id = doc.get("refund_upi_id", "")
        self.created_at = doc.get("created_at", datetime.utcnow())

    @staticmethod
    def create(user_id, table_id, reservation_date, reservation_time, guests):
        # Check if table is already booked for this date/time
        conflict = reservations_collection.find_one({
            "table_id": ObjectId(table_id),
            "reservation_date": reservation_date,
            "reservation_time": reservation_time,
            "status": {"$in": ["pending", "confirmed"]},
        })
        if conflict:
            return None  # slot already taken

        amount = guests * PRICE_PER_GUEST

        doc = {
            "user_id": ObjectId(user_id),
            "table_id": ObjectId(table_id),
            "reservation_date": reservation_date,
            "reservation_time": reservation_time,
            "guests": guests,
            "status": "pending",
            "amount": amount,
            "payment_status": "unpaid",
            "upi_txn_id": "",
            "payment_verified": "unverified",
            "verified_at": None,
            "verify_note": "",
            "refund_status": "none",
            "refund_upi_id": "",
            "created_at": datetime.utcnow(),
        }
        result = reservations_collection.insert_one(doc)
        doc["_id"] = result.inserted_id
        return Reservation(doc)

    @staticmethod
    def get_by_user(user_id):
        docs = reservations_collection.find(
            {"user_id": ObjectId(user_id)}
        ).sort("reservation_date", -1)
        return [Reservation(d) for d in docs]

    @staticmethod
    def get_all():
        docs = reservations_collection.find().sort("reservation_date", -1)
        return [Reservation(d) for d in docs]

    @staticmethod
    def get_by_id(reservation_id):
        doc = reservations_collection.find_one({"_id": ObjectId(reservation_id)})
        return Reservation(doc) if doc else None

    @staticmethod
    def update_status(reservation_id, status):
        """Update reservation status. If rejected and payment was made, trigger refund."""
        update_fields = {"status": status}
        if status == "rejected":
            # Check if customer had paid — if so, mark refund as pending
            doc = reservations_collection.find_one({"_id": ObjectId(reservation_id)})
            if doc and doc.get("payment_status") == "paid":
                update_fields["refund_status"] = "pending"
        reservations_collection.update_one(
            {"_id": ObjectId(reservation_id)}, {"$set": update_fields}
        )

    @staticmethod
    def mark_refund_sent(reservation_id, refund_upi_id):
        """Admin marks refund as sent after transferring money to customer."""
        reservations_collection.update_one(
            {"_id": ObjectId(reservation_id)},
            {"$set": {"refund_status": "sent", "refund_upi_id": refund_upi_id}},
        )

    @staticmethod
    def get_pending_refunds():
        """Return all reservations with a pending refund."""
        docs = reservations_collection.find({"refund_status": "pending"})
        return [Reservation(d) for d in docs]

    @staticmethod
    def update_payment(reservation_id, upi_txn_id):
        reservations_collection.update_one(
            {"_id": ObjectId(reservation_id)},
            {"$set": {
                "payment_status": "paid",
                "upi_txn_id": upi_txn_id,
                "payment_verified": "unverified",   # awaits admin check
            }},
        )

    @staticmethod
    def verify_payment(reservation_id, note=""):
        """Admin confirms money was received — mark verified."""
        reservations_collection.update_one(
            {"_id": ObjectId(reservation_id)},
            {"$set": {
                "payment_verified": "verified",
                "verified_at": datetime.utcnow(),
                "verify_note": note,
            }},
        )

    @staticmethod
    def fail_payment(reservation_id, note=""):
        """
        Admin rejects payment (UTR wrong / money not received).
        Resets payment to unpaid so customer must pay again,
        and marks reservation back to pending.
        """
        reservations_collection.update_one(
            {"_id": ObjectId(reservation_id)},
            {"$set": {
                "payment_status": "unpaid",
                "payment_verified": "failed",
                "upi_txn_id": "",
                "verify_note": note,
            }},
        )

    @staticmethod
    def get_pending_verification():
        """All paid reservations that admin has not verified yet."""
        docs = reservations_collection.find({
            "payment_status": "paid",
            "payment_verified": "unverified",
        }).sort("created_at", 1)   # oldest first — process in order
        return [Reservation(d) for d in docs]

    @staticmethod
    def count_pending_verification():
        return reservations_collection.count_documents({
            "payment_status": "paid",
            "payment_verified": "unverified",
        })

    @staticmethod
    def get_total_revenue():
        """
        Net revenue = total paid  −  total refunded (refund_status: sent).
        """
        # Total collected
        r_paid = reservations_collection.aggregate([
            {"$match": {"payment_status": "paid"}},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
        ])
        paid = (list(r_paid) or [{"total": 0}])[0]["total"]

        # Total refunded (only "sent" refunds are real money out)
        r_refunded = reservations_collection.aggregate([
            {"$match": {"refund_status": "sent"}},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}}},
        ])
        refunded = (list(r_refunded) or [{"total": 0}])[0]["total"]

        return paid - refunded

    @staticmethod
    def get_financial_summary():
        """Return a dict with gross, refunded, net, pending_refund totals."""
        pipeline_paid = [
            {"$match": {"payment_status": "paid"}},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}, "count": {"$sum": 1}}},
        ]
        pipeline_refunded = [
            {"$match": {"refund_status": "sent"}},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}, "count": {"$sum": 1}}},
        ]
        pipeline_pending = [
            {"$match": {"refund_status": "pending"}},
            {"$group": {"_id": None, "total": {"$sum": "$amount"}, "count": {"$sum": 1}}},
        ]

        def run(p):
            r = list(reservations_collection.aggregate(p))
            return r[0] if r else {"total": 0, "count": 0}

        paid    = run(pipeline_paid)
        sent    = run(pipeline_refunded)
        pending = run(pipeline_pending)

        return {
            "gross":         paid["total"],
            "gross_count":   paid["count"],
            "refunded":      sent["total"],
            "refunded_count":sent["count"],
            "pending_refund":pending["total"],
            "pending_count": pending["count"],
            "net":           paid["total"] - sent["total"],
        }

    @staticmethod
    def get_all_refunds():
        """Return all reservations that have a refund (any status except none)."""
        docs = reservations_collection.find(
            {"refund_status": {"$ne": "none"}}
        ).sort("created_at", -1)
        return [Reservation(d) for d in docs]

    @staticmethod
    def cancel(reservation_id, user_id=None):
        query = {"_id": ObjectId(reservation_id)}
        if user_id:
            query["user_id"] = ObjectId(user_id)
        reservations_collection.update_one(query, {"$set": {"status": "cancelled"}})

    @staticmethod
    def delete(reservation_id):
        reservations_collection.delete_one({"_id": ObjectId(reservation_id)})

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "table_id": self.table_id,
            "reservation_date": self.reservation_date,
            "reservation_time": self.reservation_time,
            "guests": self.guests,
            "status": self.status,
            "amount": self.amount,
            "payment_status": self.payment_status,
            "upi_txn_id": self.upi_txn_id,
            "payment_verified": self.payment_verified,
            "verify_note": self.verify_note,
            "refund_status": self.refund_status,
            "refund_upi_id": self.refund_upi_id,
        }
