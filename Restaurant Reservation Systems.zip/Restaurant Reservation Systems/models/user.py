from bson import ObjectId
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from database.mongodb import users_collection


class User(UserMixin):
    def __init__(self, user_doc):
        self.id = str(user_doc["_id"])
        self.name = user_doc["name"]
        self.email = user_doc["email"]
        self.phone = user_doc.get("phone", "")
        self.role = user_doc.get("role", "customer")

    @staticmethod
    def create(name, email, phone, password, role="customer"):
        if users_collection.find_one({"email": email}):
            return None  # email already in use
        doc = {
            "name": name,
            "email": email,
            "phone": phone,
            "password": generate_password_hash(password),
            "role": role,
        }
        result = users_collection.insert_one(doc)
        doc["_id"] = result.inserted_id
        return User(doc)

    @staticmethod
    def get_by_email(email):
        doc = users_collection.find_one({"email": email})
        return User(doc) if doc else None

    @staticmethod
    def get_by_id(user_id):
        doc = users_collection.find_one({"_id": ObjectId(user_id)})
        return User(doc) if doc else None

    @staticmethod
    def verify_password(email, password):
        doc = users_collection.find_one({"email": email})
        if doc and check_password_hash(doc["password"], password):
            return User(doc)
        return None

    @staticmethod
    def get_all_customers():
        docs = users_collection.find({"role": "customer"})
        return [User(d) for d in docs]

    def is_admin(self):
        return self.role == "admin"
