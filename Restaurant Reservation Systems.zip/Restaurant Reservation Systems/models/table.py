from bson import ObjectId
from database.mongodb import tables_collection


class Table:
    def __init__(self, doc):
        self.id = str(doc["_id"])
        self.table_number = doc["table_number"]
        self.capacity = doc["capacity"]
        self.status = doc.get("status", "available")

    @staticmethod
    def get_all():
        return [Table(d) for d in tables_collection.find().sort("table_number", 1)]

    @staticmethod
    def get_available(guests):
        """Return tables that are available and can seat the given number of guests."""
        docs = tables_collection.find(
            {"status": "available", "capacity": {"$gte": guests}}
        ).sort("capacity", 1)
        return [Table(d) for d in docs]

    @staticmethod
    def get_by_id(table_id):
        doc = tables_collection.find_one({"_id": ObjectId(table_id)})
        return Table(doc) if doc else None

    @staticmethod
    def update_status(table_id, status):
        tables_collection.update_one(
            {"_id": ObjectId(table_id)}, {"$set": {"status": status}}
        )

    @staticmethod
    def add_table(table_number, capacity):
        doc = {"table_number": table_number, "capacity": capacity, "status": "available"}
        result = tables_collection.insert_one(doc)
        doc["_id"] = result.inserted_id
        return Table(doc)

    @staticmethod
    def delete_table(table_id):
        tables_collection.delete_one({"_id": ObjectId(table_id)})
