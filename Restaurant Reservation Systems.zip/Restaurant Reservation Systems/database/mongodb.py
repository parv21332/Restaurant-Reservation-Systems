from pymongo import MongoClient
from config import Config

client = MongoClient(Config.MONGO_URI)
db = client.get_database()

# Collections
users_collection = db["users"]
tables_collection = db["tables"]
reservations_collection = db["reservations"]

def init_db():
    """Seed tables if the collection is empty."""
    if tables_collection.count_documents({}) == 0:
        tables = [
            {"table_number": i, "capacity": cap, "status": "available"}
            for i, cap in enumerate(
                [2, 2, 4, 4, 4, 6, 6, 8, 8, 10], start=1
            )
        ]
        tables_collection.insert_many(tables)
        print("Tables seeded successfully.")
