# Smart Restaurant Reservation and Table Management System

A full-stack web application built with **HTML/CSS/JavaScript**, **Python (Flask)**, and **MongoDB**.

---

## Tech Stack

| Layer      | Technology              |
|------------|-------------------------|
| Frontend   | HTML5, CSS3, JavaScript |
| Backend    | Python 3, Flask         |
| Database   | MongoDB (PyMongo)       |
| Auth       | Flask-Login, Werkzeug   |

---

## Project Structure

```
restaurant-reservation-system/
├── app.py                  # Main Flask application & routes
├── config.py               # Configuration (env vars)
├── setup_admin.py          # One-time admin + seed script
├── requirements.txt
├── .env                    # Environment variables (not committed)
│
├── database/
│   └── mongodb.py          # DB connection & collection handles
│
├── models/
│   ├── user.py             # User model (CRUD + auth)
│   ├── table.py            # Table model (CRUD)
│   └── reservation.py      # Reservation model (CRUD + conflict check)
│
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── reservation.html
│   ├── dashboard.html
│   └── admin.html
│
└── static/
    ├── css/style.css
    └── js/main.js
```

---

## Quick Start

### 1. Prerequisites
- Python 3.9+
- MongoDB running locally on port 27017 (or set `MONGO_URI` in `.env`)

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure environment
Edit `.env`:
```
SECRET_KEY=your-secret-key
MONGO_URI=mongodb://localhost:27017/restaurant_db
```

### 4. Seed the database and create admin
```bash
python setup_admin.py
```
Default admin credentials: `admin@smartdine.com` / `admin123`

### 5. Run the application
```bash
python app.py
```
Visit `http://127.0.0.1:5000`

---

## Features

### Customer
- Register & login
- View real-time table availability
- Book a table (best-fit algorithm)
- View booking history
- Cancel reservations

### Admin
- Dashboard with summary stats
- Approve / reject / delete reservations
- Add / delete tables
- View all customers

---

## MongoDB Collections

**users** — name, email, phone, hashed password, role  
**tables** — table_number, capacity, status  
**reservations** — user_id, table_id, date, time, guests, status
