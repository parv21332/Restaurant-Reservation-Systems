/**
 * SmartDine — Premium UI Interactions
 * Glassmorphism · Micro-animations · Buttery-smooth UX
 */

/* ─────────────────────────────────────────────────────────────────────────────
   UTILITY
───────────────────────────────────────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ─────────────────────────────────────────────────────────────────────────────
   DOM READY
───────────────────────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initToasts();
  initFormEnhancements();
  initPasswordToggle();
  initPasswordStrength();
  initButtonRipple();
  initTableRowHighlight();
  initStaggerAnimation();
  initNavActive();
  initTableMobileLabels();   // ← mobile card table labels
});

/* ─────────────────────────────────────────────────────────────────────────────
   NAVBAR — scroll shrink + mobile toggle
───────────────────────────────────────────────────────────────────────────── */
function initNavbar() {
  const navbar    = $('#navbar');
  const toggle    = $('#navToggle');
  const navLinks  = $('#navLinks');
  if (!navbar) return;

  // Scroll effect
  const onScroll = () => {
    navbar.classList.toggle('scrolled', window.scrollY > 10);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  // Mobile hamburger
  if (toggle && navLinks) {
    toggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      toggle.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', open);
    });

    // Close on outside click
    document.addEventListener('click', e => {
      if (!navbar.contains(e.target)) {
        navLinks.classList.remove('open');
        toggle.classList.remove('open');
        toggle.setAttribute('aria-expanded', false);
      }
    });

    // Close on nav link click (mobile)
    $$('a', navLinks).forEach(a => {
      a.addEventListener('click', () => {
        navLinks.classList.remove('open');
        toggle.classList.remove('open');
      });
    });
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   NAV ACTIVE HIGHLIGHT
───────────────────────────────────────────────────────────────────────────── */
function initNavActive() {
  const path = window.location.pathname;
  $$('.nav-links a').forEach(a => {
    const href = a.getAttribute('href');
    if (href && href !== '/' && path.startsWith(href)) {
      a.classList.add('active');
    }
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   TOASTS — auto-dismiss with slide-out
───────────────────────────────────────────────────────────────────────────── */
function initToasts() {
  $$('.alert').forEach((alert, i) => {
    // Stagger entrance
    alert.style.animationDelay = `${i * 0.08}s`;

    // Close button
    const closeBtn = $('.alert-close', alert);
    if (closeBtn) closeBtn.addEventListener('click', () => dismissToast(alert));

    // Click anywhere to dismiss
    alert.addEventListener('click', e => {
      if (!e.target.classList.contains('alert-close')) dismissToast(alert);
    });

    // Auto-dismiss
    const delay = alert.classList.contains('alert-danger') ? 6000 : 4500;
    setTimeout(() => dismissToast(alert), delay + i * 150);
  });
}

function dismissToast(el) {
  if (el._dismissing) return;
  el._dismissing = true;
  el.style.transition = 'opacity .3s ease, transform .3s ease, max-height .35s ease, margin .35s ease, padding .35s ease';
  el.style.opacity = '0';
  el.style.transform = 'translateX(24px) scale(.95)';
  el.style.maxHeight = el.offsetHeight + 'px';
  requestAnimationFrame(() => {
    el.style.maxHeight = '0';
    el.style.marginBottom = '0';
    el.style.paddingTop = '0';
    el.style.paddingBottom = '0';
  });
  setTimeout(() => el.remove(), 400);
}

/* ─────────────────────────────────────────────────────────────────────────────
   FORM ENHANCEMENTS
───────────────────────────────────────────────────────────────────────────── */
function initFormEnhancements() {
  // Date min
  const dateInput = $('#reservation_date');
  if (dateInput) {
    dateInput.min = new Date().toISOString().split('T')[0];
  }

  // Phone digits only
  const phone = $('#phone');
  if (phone) {
    phone.addEventListener('input', () => {
      phone.value = phone.value.replace(/\D/g, '').slice(0, 10);
    });
  }

  // Register: password match
  const regForm = $('form[action*="register"]');
  if (regForm) {
    regForm.addEventListener('submit', e => {
      const pw  = $('#password');
      const cpw = $('#confirm_password');
      clearFieldError(pw); clearFieldError(cpw);
      if (pw && cpw && pw.value !== cpw.value) {
        e.preventDefault();
        showFieldError(cpw, 'Passwords do not match.');
        cpw.focus();
        shakeSelf(cpw);
        return;
      }
    });
  }

  // Submit loading state
  $$('form').forEach(form => {
    form.addEventListener('submit', () => {
      const btn = form.querySelector('button[type="submit"].btn-primary');
      if (btn && !form.dataset.noLoading) {
        setTimeout(() => {
          btn.classList.add('btn-loading');
          btn.dataset.originalText = btn.textContent;
        }, 10);
      }
    });
  });

  // Floating label focus effect on all inputs
  $$('.form-control').forEach(input => {
    input.addEventListener('focus', () => {
      input.closest('.form-group')?.classList.add('focused');
    });
    input.addEventListener('blur', () => {
      input.closest('.form-group')?.classList.remove('focused');
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   PASSWORD SHOW/HIDE
───────────────────────────────────────────────────────────────────────────── */
function initPasswordToggle() {
  $$('.input-suffix[id="togglePwd"], .input-suffix').forEach(btn => {
    const wrap  = btn.closest('.input-wrap');
    const input = wrap?.querySelector('input[type="password"], input[type="text"]');
    if (!input) return;
    btn.style.cursor = 'pointer';
    btn.addEventListener('click', () => {
      const show = input.type === 'password';
      input.type  = show ? 'text' : 'password';
      btn.textContent = show ? '🙈' : '👁';
      input.focus();
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   PASSWORD STRENGTH METER
───────────────────────────────────────────────────────────────────────────── */
function initPasswordStrength() {
  const pwInput = $('#password');
  const wrap    = $('#pwdStrengthWrap');
  const bar     = $('#pwdStrengthBar');
  const label   = $('#pwdStrengthLabel');
  if (!pwInput || !wrap) return;

  pwInput.addEventListener('input', () => {
    const val = pwInput.value;
    if (!val) { wrap.style.display = 'none'; return; }
    wrap.style.display = 'block';

    let score = 0;
    if (val.length >= 6)  score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;

    const levels = [
      { w: '20%', color: '#ef4444', text: 'Too weak' },
      { w: '40%', color: '#f97316', text: 'Weak' },
      { w: '60%', color: '#eab308', text: 'Fair' },
      { w: '80%', color: '#22c55e', text: 'Strong' },
      { w: '100%',color: '#16a34a', text: 'Very strong' },
    ];
    const lv = levels[Math.min(score - 1, 4)] || levels[0];
    bar.style.width  = lv.w;
    bar.style.background = lv.color;
    label.textContent = lv.text;
    label.style.color = lv.color;
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   BUTTON RIPPLE
───────────────────────────────────────────────────────────────────────────── */
function initButtonRipple() {
  $$('.btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const rect   = this.getBoundingClientRect();
      const x      = e.clientX - rect.left;
      const y      = e.clientY - rect.top;
      const ripple = document.createElement('span');
      const size   = Math.max(rect.width, rect.height) * 2;

      Object.assign(ripple.style, {
        position:  'absolute',
        width:     size + 'px',
        height:    size + 'px',
        left:      (x - size / 2) + 'px',
        top:       (y - size / 2) + 'px',
        background:'rgba(255,255,255,.25)',
        borderRadius:'50%',
        transform: 'scale(0)',
        animation: 'ripple .55s linear',
        pointerEvents:'none',
      });

      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 600);
    });
  });

  // Inject keyframes once
  if (!document.getElementById('rippleStyle')) {
    const s = document.createElement('style');
    s.id = 'rippleStyle';
    s.textContent = '@keyframes ripple{to{transform:scale(1);opacity:0}}';
    document.head.appendChild(s);
  }
}

/* ─────────────────────────────────────────────────────────────────────────────
   TABLE ROW HOVER HIGHLIGHT
───────────────────────────────────────────────────────────────────────────── */
function initTableRowHighlight() {
  $$('.data-table tbody tr').forEach(tr => {
    tr.addEventListener('mouseenter', () => {
      tr.style.transition = 'background .12s ease';
    });
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   STAGGER ANIMATION (Intersection Observer)
───────────────────────────────────────────────────────────────────────────── */
function initStaggerAnimation() {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  $$('.section-in, .feature-card, .stat-card').forEach(el => {
    el.style.animationPlayState = 'paused';
    observer.observe(el);
  });
}

/* ─────────────────────────────────────────────────────────────────────────────
   FIELD ERROR HELPERS
───────────────────────────────────────────────────────────────────────────── */
function showFieldError(input, message) {
  clearFieldError(input);
  input.classList.add('error');
  const err = document.createElement('span');
  err.className = 'form-error';
  err.textContent = message;
  input.closest('.form-group')?.appendChild(err);
  input.addEventListener('input', () => clearFieldError(input), { once: true });
}

function clearFieldError(input) {
  input.classList.remove('error');
  input.closest('.form-group')?.querySelector('.form-error')?.remove();
}

function shakeSelf(el) {
  el.animate([
    { transform: 'translateX(0)' },
    { transform: 'translateX(-6px)' },
    { transform: 'translateX(6px)' },
    { transform: 'translateX(-4px)' },
    { transform: 'translateX(4px)' },
    { transform: 'translateX(0)' },
  ], { duration: 380, easing: 'ease-in-out' });
}

/* ─────────────────────────────────────────────────────────────────────────────
   TABLE MOBILE LABELS
   Reads <th> text and sets data-label on every matching <td>
   so the CSS ::before pseudo-element can show field names in card view.
───────────────────────────────────────────────────────────────────────────── */
function initTableMobileLabels() {
  $$('.data-table').forEach(table => {
    const headers = $$('thead th', table).map(th => th.textContent.trim());
    $$('tbody tr', table).forEach(row => {
      $$('td', row).forEach((td, i) => {
        if (headers[i]) td.setAttribute('data-label', headers[i]);
      });
    });
  });
}
