"""
Run this script once to create the default admin account and seed tables.
Usage: python setup_admin.py
"""

from database.mongodb import init_db, users_collection
from werkzeug.security import generate_password_hash

def create_admin():
    email = "admin@smartdine.com"
    if users_collection.find_one({"email": email}):
        print(f"Admin already exists: {email}")
        return

    users_collection.insert_one({
        "name": "Admin",
        "email": email,
        "phone": "0000000000",
        "password": generate_password_hash("admin123"),
        "role": "admin",
    })
    print(f"Admin created → email: {email}  password: admin123")

if __name__ == "__main__":
    init_db()
    create_admin()
    print("Setup complete.")
